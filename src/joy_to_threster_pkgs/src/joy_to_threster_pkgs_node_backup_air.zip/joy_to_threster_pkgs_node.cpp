#include "ros/ros.h"
#include "sensor_msgs/Joy.h"
#include "joy_to_threster_pkgs/Therster.h"
#include <iostream>

bool flag = true;
bool control_mode = true;
int abs_num;
int data[10] = {1500,1500,1500,1500,1500,1500,1500,1500,0,0};
int num = 0;
int num_1 = 0;

void joyCallback(const sensor_msgs::Joy::ConstPtr& joy_msg) {
    
    // Joy 메시지에서 필요한 데이터 추출 (예시로 axes와 buttons의 첫 번째 값을 사용)
    float axis_value = joy_msg->axes[7];
    float axis_value_1 = joy_msg->axes[6];
    int button_value = joy_msg->buttons[0];
    int mode_change_button = joy_msg->buttons[1];
    float axis_forward = joy_msg->axes[1];
    float axis_side = joy_msg->axes[0];
    int boost_button_value = joy_msg->buttons[4];
    // printf("joy : %f", axis_value);
    
    if(mode_change_button == 1){
        if(control_mode == true){
            control_mode = false;
            printf("JOY_nobe_mode\n");
            printf("JOY_nobe_mode\n");
            printf("JOY_nobe_mode\n");
        }
        else{
            control_mode = true;
            printf("JOY_button_mode\n");
            printf("JOY_button_mode\n");
            printf("JOY_button_mode\n");
        }
    }
    if(button_value == 1){

        if(flag == true){
        flag = false;
        printf("change_mode_non_control\n");
        num = 0;
        num_1 = 0;
        }
        else{
        flag = true;
        printf("change_mode_joy_control\n");
        }
    }
    
    if(control_mode == true){
    if(flag == true){
        if(boost_button_value == 1){
            printf("boost_Mode\n");
            if(axis_value == 1 && num <13){
                num = num + 2;
                printf("num : %d\n",num);
            }
            else if(axis_value == 1 && num <=13){
                num = 13;
            }
            else if(axis_value == -1 && num > -13){
            num = num - 2;
            printf("num : %d\n",num);
            }
            else if(axis_value == -1 && num >= -13){
                num = -13;
            }
        }
        else{
            if(axis_value == 1 && num <100){ // 4
                num = num + 1;
                printf("num : %d\n",num);
            }
        else if(axis_value == -1 && num > -100){ // -4
            num = num - 1;
            printf("num : %d\n",num);
        }
        }
    }
    else{
            num = 0;
    }

    if(flag == true){
        if(boost_button_value == 1){
            printf("boost_Mode\n");
            if(axis_value_1 == 1 && num_1 <13){
                num_1 = num_1 + 2;
                printf("num_1 : %d\n",num_1);
            }
            else if(axis_value_1 == 1 && num_1 <=13){
                num_1 = 13;
            }
            else if(axis_value_1 == -1 && num_1 > -13){
            num_1 = num_1 - 2;
            printf("num_1 : %d\n",num_1);
            }
            else if(axis_value_1 == -1 && num_1 >= -13){
                num_1 = -13;
            }
        }
        else{
        if(axis_value_1 == 1 && num_1 <4){
            num_1 = num_1 + 1;
            printf("num_1 : %d\n",num_1);
        }
        else if(axis_value_1 == -1 && num_1 > -4){
            num_1 = num_1 - 1;
            printf("num_1 : %d\n",num_1);
        }
        }
    }

    else{
            num = 0;
    }
    
            data[0] = num * 5 + 1500;
            data[1] = num * 5 + 1500;
            data[2] = num * 5 + 1500;
            data[3] = num * 5 + 1500;
            data[4] = num_1 * 25 + 1500;
            data[5] = num_1 * 25 + 1500;
            data[6] = num_1 * 25 + 1500;
            data[7] = num_1 * 25 + 1500;
            data[8] = 0;
            data[9] = 0;
    }

    else if(flag == true){
        printf("up : %d\n side : %d\n",data[0],data[4]);
        data[0] = axis_forward * 300 + 1500;
        data[1] = axis_forward * 300 + 1500;
        data[2] = axis_forward * 300 + 1500;
        data[3] = axis_forward * 300 + 1500;
        data[4] = axis_side * 300 + 1500;
        data[5] = axis_side * 300 + 1500;
        data[6] = axis_side * 300 + 1500;
        data[7] = axis_side * 300 + 1500;
        data[8] = 0;
        data[9] = 0;
    }
    // 커스텀 메시지 Therster를 생성하고 데이터 채우기
    
    // 커스텀 메시지 발행
    
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "joy_to_therster_node");
    ros::NodeHandle nh;

    // Joy 메시지 구독자 선언
    joy_to_threster_pkgs::Therster therster_msg;
    
    ros::Subscriber joy_sub = nh.subscribe<sensor_msgs::Joy>("/joy", 1000, &joyCallback);
    ros::Publisher therster_pub = nh.advertise<joy_to_threster_pkgs::Therster>("/therster_topic", 1000);
    ros::Rate loop_rate(100);
    int i = 0;
    while (ros::ok())
   {
     /**
      * This is a message object. You stuff it with data, and then publish it.
      */

    // printf("while_run\n");
    while(true){
        therster_msg.Therster[i] = data[i];
        // printf("data [%d]: %d \n",i ,data[i]);
        i = i + 1;
        if(i == 9){
            i = 0;
            break;
        }
    }
    // for(int i=0;i=9;i++){
    //     therster_msg.Therster[i] = data[i];
    //     printf("data [%d]: %d ",i ,data[i]);
    // }

    therster_pub.publish(therster_msg);
     /**
      * The publish() function is how you send messages. The parameter
      * is the message object. The type of this object must agree with the type
      * given as a template parameter to the advertise<>() call, as was done
      * in the constructor above.
      */
 
     ros::spinOnce();
 
     loop_rate.sleep();

   }
 
    return 0;
}