#!/usr/bin/env python3

import rospy
import serial as pyserial
from arduino_serial_communication.msg import Therster

def therester_callback(data):
    # 시리얼 포트 설정 (ttyUSB0 대신에 사용하는 포트명을 적절히 변경해주세요.)
    ser = pyserial.Serial('/dev/ttyACM0',1000000)  # 포트 이름과 보드의 전송 속도에 맞게 수정

    # 데이터를 쉼표로 구분하여 시리얼 포트로 전송
    data_str = ','.join([str(value) for value in data.Therster])
    data_str += 'a'
    # data_str += '\n'
    ser.write(data_str.encode())
    # ser.write(data_str.encode('utf-8'))

    print("Data sent:", data_str)
    # 시리얼 데이터를 읽어서 콘솔에 출력
    # while ser.in_waiting:
    #     print(ser.readline().decode(), end='')

    # 시리얼 포트 닫기
    while ser.in_waiting:
        received_data = ser.readline().decode().strip()
        print("Received data:", received_data)
    ser.close()

def therester_serial_communication_node():
    rospy.init_node('therester_serial_communication_node', anonymous=True)
    rospy.Subscriber('/therster_topic', Therster, therester_callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        therester_serial_communication_node()
    except rospy.ROSInterruptException:
        pass
